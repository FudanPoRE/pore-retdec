/**
 * @file tests/doxygen.h
 * @brief Doxygen documentation of the yaramod::tests namespace.
 * @copyright AVG Technologies s.r.o, All Rights Reserved
 */

// As there is no better place to comment this namespace, we do this in the
// present file.

/// @namespace yaramod::tests Tests for `yaramod`.
