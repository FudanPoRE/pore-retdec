#pragma once

#define POG_VERSION "0.5.3"

#include <pog/html_report.h>
#include <pog/parser.h>
