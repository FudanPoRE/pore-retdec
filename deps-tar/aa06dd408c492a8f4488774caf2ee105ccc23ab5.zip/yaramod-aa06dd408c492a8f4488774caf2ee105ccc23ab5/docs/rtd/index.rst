.. yaramod documentation master file, created by
   sphinx-quickstart on Fri Feb 21 12:31:51 2020.
   You can adapt this file completely to your liking, but it should at least
   contain the root `toctree` directive.

Welcome to yaramod's documentation!
===================================

Welcome to the documentation of our project Yaramod. Parser and builder for YARA rulesets.

.. toctree::
   :maxdepth: 2

   installation
   getting_started
   parsing_rulesets
   creating_rulesets
   formatting_rulesets
   modifying_rulesets
   examples
   development
   deployment
   troubleshooting
   future_of_yaramod
