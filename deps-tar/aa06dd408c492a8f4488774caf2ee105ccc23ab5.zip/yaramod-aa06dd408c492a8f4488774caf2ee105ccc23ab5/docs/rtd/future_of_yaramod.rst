Future of yaramod
===================

This page is intented to be a collection of ideas for the future of yaramod.

.. * It would be nice to have some option to access more than just the first and last token of an expression.
