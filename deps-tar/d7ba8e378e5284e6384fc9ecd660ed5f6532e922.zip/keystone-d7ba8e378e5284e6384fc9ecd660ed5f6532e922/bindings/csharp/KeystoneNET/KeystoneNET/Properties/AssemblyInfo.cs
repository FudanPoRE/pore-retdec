﻿using System.Reflection;
using System.Runtime.InteropServices;

[assembly: AssemblyTitle("KeystoneNET")]
[assembly: AssemblyDescription("Keystone bindings for .NET")]
[assembly: AssemblyConfiguration("")]
[assembly: AssemblyCompany("")]
[assembly: AssemblyProduct("Keystone")]
[assembly: AssemblyCopyright("Copyright ©  2017")]
[assembly: AssemblyTrademark("")]
[assembly: AssemblyCulture("")]

[assembly: ComVisible(false)]

[assembly: Guid("2fe3b804-90f7-4632-b6f4-f72548e26984")]

[assembly: AssemblyVersion("1.0.0.0")]
[assembly: AssemblyFileVersion("1.0.0.0")]
