// For Keystone Engine. AUTO-GENERATED FILE, DO NOT EDIT [hexagonConstants.cs]
namespace KeystoneNET
{
	public enum HexagonError : short
	{
		KS_ERR_ASM_HEXAGON_INVALIDOPERAND = 512,
		KS_ERR_ASM_HEXAGON_MISSINGFEATURE = 513,
		KS_ERR_ASM_HEXAGON_MNEMONICFAIL = 514,
	}
}