// For Keystone Engine. AUTO-GENERATED FILE, DO NOT EDIT [ppcConstants.cs]
namespace KeystoneNET
{
	public enum PpcError : short
	{
		KS_ERR_ASM_PPC_INVALIDOPERAND = 512,
		KS_ERR_ASM_PPC_MISSINGFEATURE = 513,
		KS_ERR_ASM_PPC_MNEMONICFAIL = 514,
	}
}