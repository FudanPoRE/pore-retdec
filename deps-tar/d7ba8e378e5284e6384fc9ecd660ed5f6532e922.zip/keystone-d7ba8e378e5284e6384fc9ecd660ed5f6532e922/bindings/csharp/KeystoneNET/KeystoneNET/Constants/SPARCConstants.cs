// For Keystone Engine. AUTO-GENERATED FILE, DO NOT EDIT [sparcConstants.cs]
namespace KeystoneNET
{
	public enum SparcError : short
	{
		KS_ERR_ASM_SPARC_INVALIDOPERAND = 512,
		KS_ERR_ASM_SPARC_MISSINGFEATURE = 513,
		KS_ERR_ASM_SPARC_MNEMONICFAIL = 514,
	}
}