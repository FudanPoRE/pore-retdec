// For Keystone Engine. AUTO-GENERATED FILE, DO NOT EDIT [systemzConstants.cs]
namespace KeystoneNET
{
	public enum SystemzError : short
	{
		KS_ERR_ASM_SYSTEMZ_INVALIDOPERAND = 512,
		KS_ERR_ASM_SYSTEMZ_MISSINGFEATURE = 513,
		KS_ERR_ASM_SYSTEMZ_MNEMONICFAIL = 514,
	}
}