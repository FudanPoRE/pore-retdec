// For Keystone Engine. AUTO-GENERATED FILE, DO NOT EDIT [armConstants.cs]
namespace KeystoneNET
{
	public enum ArmError : short
	{
		KS_ERR_ASM_ARM_INVALIDOPERAND = 512,
		KS_ERR_ASM_ARM_MISSINGFEATURE = 513,
		KS_ERR_ASM_ARM_MNEMONICFAIL = 514,
	}
}