// For Keystone Engine. AUTO-GENERATED FILE, DO NOT EDIT [arm64Constants.cs]
namespace KeystoneNET
{
	public enum Arm64Error : short
	{
		KS_ERR_ASM_ARM64_INVALIDOPERAND = 512,
		KS_ERR_ASM_ARM64_MISSINGFEATURE = 513,
		KS_ERR_ASM_ARM64_MNEMONICFAIL = 514,
	}
}