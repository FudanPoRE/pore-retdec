package keystone
// For Keystone Engine. AUTO-GENERATED FILE, DO NOT EDIT [mips_const.go]

const (
	ERR_ASM_MIPS_INVALIDOPERAND Error = 512
	ERR_ASM_MIPS_MISSINGFEATURE Error = 513
	ERR_ASM_MIPS_MNEMONICFAIL Error = 514
)

