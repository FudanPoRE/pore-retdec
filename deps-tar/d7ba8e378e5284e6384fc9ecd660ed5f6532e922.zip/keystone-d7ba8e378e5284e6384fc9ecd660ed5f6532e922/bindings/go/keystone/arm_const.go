package keystone
// For Keystone Engine. AUTO-GENERATED FILE, DO NOT EDIT [arm_const.go]

const (
	ERR_ASM_ARM_INVALIDOPERAND Error = 512
	ERR_ASM_ARM_MISSINGFEATURE Error = 513
	ERR_ASM_ARM_MNEMONICFAIL Error = 514
)

