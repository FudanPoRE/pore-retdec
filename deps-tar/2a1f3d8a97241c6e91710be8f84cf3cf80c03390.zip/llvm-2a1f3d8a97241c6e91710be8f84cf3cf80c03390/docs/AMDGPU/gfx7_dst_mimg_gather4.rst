..
    **************************************************
    *                                                *
    *   Automatically generated file, do not edit!   *
    *                                                *
    **************************************************

.. _amdgpu_synid7_dst_mimg_gather4:

vdst
===========================

Image data to load by an *image_gather4* instruction.

*Size:* 4 data elements by default. Each data element occupies 1 dword. :ref:`tfe<amdgpu_synid_tfe>` adds one more dword if specified.

*Operands:* :ref:`v<amdgpu_synid_v>`
