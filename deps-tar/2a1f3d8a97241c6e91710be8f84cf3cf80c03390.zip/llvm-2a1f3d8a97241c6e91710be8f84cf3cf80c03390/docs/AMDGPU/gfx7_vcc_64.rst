..
    **************************************************
    *                                                *
    *   Automatically generated file, do not edit!   *
    *                                                *
    **************************************************

.. _amdgpu_synid7_vcc_64:

vcc
===========================

Vector condition code.

*Size:* 2 dwords.

*Operands:* :ref:`vcc<amdgpu_synid_vcc>`
