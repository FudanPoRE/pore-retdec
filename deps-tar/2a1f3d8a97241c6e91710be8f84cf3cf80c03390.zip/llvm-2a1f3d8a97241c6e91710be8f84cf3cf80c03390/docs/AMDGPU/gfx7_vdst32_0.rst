..
    **************************************************
    *                                                *
    *   Automatically generated file, do not edit!   *
    *                                                *
    **************************************************

.. _amdgpu_synid7_vdst32_0:

vdst
===========================

Instruction output.

*Size:* 1 dword.

*Operands:* :ref:`v<amdgpu_synid_v>`
