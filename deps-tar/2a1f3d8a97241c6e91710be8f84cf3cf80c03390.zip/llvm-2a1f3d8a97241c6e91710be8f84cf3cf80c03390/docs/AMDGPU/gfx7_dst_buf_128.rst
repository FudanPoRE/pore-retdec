..
    **************************************************
    *                                                *
    *   Automatically generated file, do not edit!   *
    *                                                *
    **************************************************

.. _amdgpu_synid7_dst_buf_128:

vdst
===========================

Instruction output: data read from a memory buffer.

*Size:* 4 dwords by default. :ref:`tfe<amdgpu_synid_tfe>` adds 1 dword if specified.

*Operands:* :ref:`v<amdgpu_synid_v>`
