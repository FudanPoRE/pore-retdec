..
    **************************************************
    *                                                *
    *   Automatically generated file, do not edit!   *
    *                                                *
    **************************************************

.. _amdgpu_synid9_vdata32_0:

vdata
===========================

Instruction input.

*Size:* 1 dword.

*Operands:* :ref:`v<amdgpu_synid_v>`
