..
    **************************************************
    *                                                *
    *   Automatically generated file, do not edit!   *
    *                                                *
    **************************************************

.. _amdgpu_synid8_addr_flat:

vaddr
===========================

A 64-bit flat address.

*Size:* 2 dwords.

*Operands:* :ref:`v<amdgpu_synid_v>`
