..
    **************************************************
    *                                                *
    *   Automatically generated file, do not edit!   *
    *                                                *
    **************************************************

.. _amdgpu_synid7_ssrc64_2:

ssrc
===========================

Instruction input.

*Size:* 2 dwords.

*Operands:* :ref:`s<amdgpu_synid_s>`, :ref:`flat_scratch<amdgpu_synid_flat_scratch>`, :ref:`vcc<amdgpu_synid_vcc>`, :ref:`trap<amdgpu_synid_trap>`, :ref:`exec<amdgpu_synid_exec>`, :ref:`constant<amdgpu_synid_constant>`
