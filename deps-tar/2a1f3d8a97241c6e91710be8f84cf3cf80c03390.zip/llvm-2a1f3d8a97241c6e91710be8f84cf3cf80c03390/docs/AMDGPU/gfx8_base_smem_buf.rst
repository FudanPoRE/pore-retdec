..
    **************************************************
    *                                                *
    *   Automatically generated file, do not edit!   *
    *                                                *
    **************************************************

.. _amdgpu_synid8_base_smem_buf:

sbase
===========================

A 128-bit buffer resource constant for scalar memory operations which provides a base address, a size and a stride.

*Size:* 4 dwords.

*Operands:* :ref:`s<amdgpu_synid_s>`, :ref:`ttmp<amdgpu_synid_ttmp>`
