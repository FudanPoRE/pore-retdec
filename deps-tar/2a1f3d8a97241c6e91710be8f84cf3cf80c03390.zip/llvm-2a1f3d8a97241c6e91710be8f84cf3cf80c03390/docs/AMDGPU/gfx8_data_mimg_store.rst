..
    **************************************************
    *                                                *
    *   Automatically generated file, do not edit!   *
    *                                                *
    **************************************************

.. _amdgpu_synid8_data_mimg_store:

vdata
===========================

Image data to store by an *image_store* instruction.

*Size:* depends on :ref:`dmask<amdgpu_synid_dmask>` which may specify from 1 to 4 data elements. Each data element occupies 1 dword.


*Operands:* :ref:`v<amdgpu_synid_v>`
