..
    **************************************************
    *                                                *
    *   Automatically generated file, do not edit!   *
    *                                                *
    **************************************************

.. _amdgpu_synid9_vaddr_flat_scratch:

vaddr
===========================

An optional 32-bit flat scratch offset. Must be specified as :ref:`off<amdgpu_synid_off>` if not used.

Either this operand or :ref:`saddr<amdgpu_synid9_saddr_flat_scratch>` must be set to :ref:`off<amdgpu_synid_off>`.

*Size:* 1 dword.

*Operands:* :ref:`v<amdgpu_synid_v>`, :ref:`off<amdgpu_synid_off>`
