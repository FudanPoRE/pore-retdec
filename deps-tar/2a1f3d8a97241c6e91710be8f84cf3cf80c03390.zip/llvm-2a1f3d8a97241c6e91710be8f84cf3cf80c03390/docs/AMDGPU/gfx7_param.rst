..
    **************************************************
    *                                                *
    *   Automatically generated file, do not edit!   *
    *                                                *
    **************************************************

.. _amdgpu_synid7_param:

param
===========================

Interpolation parameter to read:

    ============ ===================================
    Syntax       Description
    ============ ===================================
    p0           Parameter *P0*.
    p10          Parameter *P10*.
    p20          Parameter *P20*.
    ============ ===================================

